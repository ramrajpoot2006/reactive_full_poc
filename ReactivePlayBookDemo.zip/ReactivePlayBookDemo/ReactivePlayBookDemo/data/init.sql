CREATE TABLE Customer(
   customerId serial PRIMARY KEY,
   orderNo VARCHAR (500),
   name VARCHAR (500),
   address VARCHAR (500)
 
);