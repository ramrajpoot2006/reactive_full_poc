package com.example.reactiveplaybook.demo.repository;

import java.util.UUID;

import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.relational.core.query.Criteria;
import org.springframework.data.relational.core.query.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import org.springframework.stereotype.Repository;

import com.example.reactiveplaybook.demo.entity.Customer;

import reactor.core.publisher.Mono;
@Repository
public class CustomerReadRepository {
	
	  private final R2dbcEntityTemplate entityTemplate;

	  public CustomerReadRepository(R2dbcEntityTemplate entityTemplate) {
	    this.entityTemplate = entityTemplate;
	  }

	  public Mono<Customer> findByCustomerId(Integer customerId) {
	    return entityTemplate.selectOne(Query.query(Criteria.where("customerId").is(customerId)),
	    		Customer.class);
	  }

	}


