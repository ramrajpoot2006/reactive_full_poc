package com.example.reactiveplaybook.demo.controller;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.reactiveplaybook.demo.entity.Customer;
import com.example.reactiveplaybook.demo.mapper.CustomerMapper;
import com.example.reactiveplaybook.demo.service.CustomerService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/customers")
@Slf4j
public class CustomerController {
	@Autowired
	private final CustomerService customerService;

	  public CustomerController(CustomerService customerService) {
	    this.customerService = customerService;
	  }
	  @GetMapping(value = "/{customerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	  public Mono<ResponseEntity<Customer>> getCustomer(
	      @PathVariable Integer customerId) {
	    return customerService.getCustomer(customerId)
	        .doFirst(() -> log.info("Request received fetch customer details for id : {}", customerId))
	        .map(customer -> ResponseEntity.ok().body(new CustomerMapper().apply(customer)))
	        .doOnSuccess(id -> log.info("Customer details retrieved successfully : {}", id))
	        .doOnError(throwable -> log.error("Error occurred for basketId", customerId));
	  }

}
