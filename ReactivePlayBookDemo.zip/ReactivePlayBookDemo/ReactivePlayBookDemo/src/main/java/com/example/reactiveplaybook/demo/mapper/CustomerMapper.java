package com.example.reactiveplaybook.demo.mapper;
import org.springframework.stereotype.Component;
import com.example.reactiveplaybook.demo.entity.Customer;
import java.util.Optional;
import java.util.function.UnaryOperator;

@Component
public class CustomerMapper implements UnaryOperator<Customer> {

  @Override
  public Customer apply(Customer customer) {
    return Optional.ofNullable(customer.getCustomerId())
        .map(items -> customer.toBuilder()
            .build())
        .orElse(customer);
  }

}

