package com.example.reactiveplaybook.demo.service;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.reactiveplaybook.demo.entity.Customer;
import com.example.reactiveplaybook.demo.repository.CustomerReadRepository;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
@Slf4j
@Service
public class CustomerService {
	 @Autowired
	 CustomerReadRepository customerReadRepository;

	public Mono<Customer> getCustomer(Integer customerId) {
		// TODO Auto-generated method stub
		return customerReadRepository.findByCustomerId(customerId)
		        .doFirst(() -> log.debug("Processing getBasket request for customer id : {}", customerId))
		        .repeatWhenEmpty(1, longFlux -> longFlux.onErrorResume(throwable -> Mono.empty()));
		        
	}

}
