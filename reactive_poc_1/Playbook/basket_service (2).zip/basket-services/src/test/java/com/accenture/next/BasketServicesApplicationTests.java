package com.accenture.next;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasketServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
