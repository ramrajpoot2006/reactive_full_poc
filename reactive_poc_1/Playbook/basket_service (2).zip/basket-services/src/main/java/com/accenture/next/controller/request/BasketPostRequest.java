package com.accenture.next.controller.request;

public class BasketPostRequest {

}
