package com.accenture.next;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasketServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasketServicesApplication.class, args);
	}

}
