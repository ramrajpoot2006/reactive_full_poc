package com.accenture.next.service;




import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.basketapi.resources.request.BasketPostRequest;
import com.accenture.next.entity.Basket;
import com.accenture.next.repository.BasketReadRepository;
import com.accenture.next.repository.BasketRepository;
import com.accenture.next.response.BasketResponse;
import com.accenture.next.responseConverter.BasketResponseConverter;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
@Service

@Slf4j
public class BasketService {

	@Autowired
	private BasketReadRepository basketRepository;
	private BasketResponseConverter basketResponseConverter;
	public BasketService(BasketReadRepository basketRepository ,BasketResponseConverter basketResponseConverter) {
		this.basketResponseConverter=basketResponseConverter;
		this.basketRepository=basketRepository;
	}
	
	

	
	 public Mono<BasketResponse> getBasket(String basketId) 
	 { // TODO
	 return basketRepository.findByBasketId(UUID.fromString(basketId))
	 .doFirst(() ->
	 log.info("Processing get basket basketid : {}", basketId))
	 .flatMap(basketResponseConverter::buildBasketResponse) ; }




	public Mono<BasketResponse> createBasket(BasketPostRequest basketPostRequest) {
		// TODO Auto-generated method stub
		Basket basket =new Basket();
		basket.setOrderNo(basketPostRequest.getOrderNo());
		basket.setOrderDate(basketPostRequest.getOrderDate());
		basket.setResourceState(basketPostRequest.getResourceState());
		basket.setEventId(basketPostRequest.getEventId());
		basket.setProductItem(basketPostRequest.getProductItem());
		basket.setLocale(basketPostRequest.getLocale());
		basket.setCustomerInformation(basketPostRequest.getCustomerInformation());
		basket.setBillingAddress(basketPostRequest.getBillingAddress());
		basket.setPaymentInstruments(basketPostRequest.getPaymentInstruments());
		return basketRepository.save(basket).flatMap(basketResponseConverter::buildBasketResponse);
	}
	 
	
				
					
	}




