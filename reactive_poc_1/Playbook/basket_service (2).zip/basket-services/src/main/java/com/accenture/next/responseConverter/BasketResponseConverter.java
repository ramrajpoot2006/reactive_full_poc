package com.accenture.next.responseConverter;

import org.springframework.stereotype.Component;

import com.accenture.next.entity.Basket;
import com.accenture.next.response.BasketResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
@Component
@Slf4j

public class BasketResponseConverter {
	public Mono<BasketResponse> buildBasketResponse(Basket basket) {
	    return Mono.just(basket)
	        .doFirst(() -> log.info("Converting basket to Basket response"))
	        .map(this::buildbasketResponse)
	        ;
	  }
	  
	  public BasketResponse buildbasketResponse(Basket basket) {
	    return BasketResponse.builder()
	    		
	    		 .basketId(basket.getBasketId())
		            .orderNo(basket.getOrderNo())
		            .orderDate(basket.getOrderDate())
		            .resourceState(basket.getResourceState())
		            .eventId(basket.getEventId())
		            .productItem(basket.getProductItem())
		            .locale(basket.getLocale())
		            .customerInformation(basket.getCustomerInformation())
		            .billingAddress(basket.getBillingAddress())
		            .paymentInstruments(basket.getPaymentInstruments())
		            .build();
	  }

	
	/*
	 * public Mono<BasketResponse> buildBasketResponse(List<Basket> basketList) {
	 * return Flux.fromIterable(basketList) .doFirst(() ->
	 * log.debug("Converting customerList to Customer response"))
	 * .flatMap(this::buildbasketResponse).collectList() .map(basketResList ->
	 * basketResList.stream().collect(Collectors.toList())); }
	 */
	/*
	 * public Mono<BasketResponse> buildbasketResponse(Basket basket) { return
	 * Mono.just(basket) .doFirst(() ->
	 * log.debug("Preparing BasketResponse response")) .flatMap(this)
	 * .map(basketMethod -> BasketResponse.builder() .basketId(basket.getBasketId())
	 * .orderNo(basket.getOrderNo()) .orderDate(basket.getOrderDate())
	 * .resourceState(basket.getResourceState()) .eventId(basket.getEventId())
	 * .productItem(basket.getProductItem()) .locale(basket.getLocale())
	 * .customerInformation(basket.getCustomerInformation())
	 * .billingAddress(basket.getBillingAddress())
	 * .paymentInstruments(basket.getPaymentInstruments()) .build()); }
	 */

}
