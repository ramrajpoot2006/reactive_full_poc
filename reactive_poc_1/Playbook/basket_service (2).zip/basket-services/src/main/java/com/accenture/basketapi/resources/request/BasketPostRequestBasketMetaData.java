/*
 * package com.accenture.basketapi.resources.request;
 * 
 * 
 * import com.fasterxml.jackson.annotation.JsonAlias; import
 * lombok.AllArgsConstructor; import lombok.Builder; import lombok.Data; import
 * lombok.EqualsAndHashCode; import lombok.NoArgsConstructor; import
 * lombok.ToString;
 * 
 * import javax.validation.Valid; import javax.validation.constraints.NotBlank;
 * import javax.validation.constraints.NotNull; import
 * javax.validation.constraints.Pattern;
 * 
 * 
 * 
 *//**
	 * BasketPostRequestBasketMetaData
	 *//*
		 * @Data
		 * 
		 * @ToString
		 * 
		 * @EqualsAndHashCode
		 * 
		 * @Builder
		 * 
		 * @AllArgsConstructor
		 * 
		 * @NoArgsConstructor public class BasketPostRequestBasketMetaData {
		 * 
		 * @Valid
		 * 
		 * @JsonAlias("customer") private BasketPostRequestBasketMetaDataCustomer
		 * customerInformation; public static final String REQUIRED_FIELD_CODE = "4001";
		 * 
		 * 
		 * @NotNull(message = REQUIRED_FIELD_CODE) private String locale;
		 * 
		 * 
		 * 
		 * }
		 */