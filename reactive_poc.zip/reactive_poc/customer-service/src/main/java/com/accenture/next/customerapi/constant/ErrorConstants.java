package com.accenture.next.customerapi.constant;

public final class ErrorConstants {

  public static final String API_MESSAGE_KEY = "shipping.api.code";
  public static final String DOT_STRING = ".";

  // Error codes
  public static final String REQUIRED_FIELD_CODE = "4001";
  public static final String REQUEST_BODY_MISSING_CODE = "4002";
  public static final String INVALID_JSON_CODE = "4003";
  public static final String CUSTOMER_NOT_FOUND_CODE = "4041";
  public static final String RECORD_NOT_FOUND_CODE = "4042";
  public static final String INVALID_FIELD_CODE = "4221";
  public static final String INTERNAL_ERROR_CODE = "5000";

  public static final String CONSTRAINT_VIOLATION_CODE = "4091";

  private ErrorConstants() {
    throw new IllegalStateException("Class constants, should not be called.");
  }
}
