package com.accenture.next.customerapi.resources.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CustomerResponse {
  
  private Integer id;
  private String name;
  private String customerType;
  private String customerCode;
  private Boolean enabled;
  private String createdBy;
  private String createdDate;
  private String modifiedBy;
  private String modifiedDate;

}
