package com.demo.webfluxdemo;

import com.demo.webfluxdemo.dto.BasketEntity;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest
class WebfluxDemoApplicationTests {

	@Test
	public void testMono(){
		BasketEntity b = new BasketEntity();
		Mono<String> monoString = Mono.just("testMono").log();
		monoString.subscribe(System.out::println);

	/*	//Error Scenario
		Mono<?> monoString1 = Mono.just("testMono")
				.then(Mono.error(new RuntimeException("Exception Occured"))).log();
		monoString1.subscribe(System.out::println);*/
	}

	@Test
	public void testFlux(){
		Flux<String> fluxString = Flux.just("test1","test2","test3").log();
		fluxString.subscribe(System.out::println);
	}


}
