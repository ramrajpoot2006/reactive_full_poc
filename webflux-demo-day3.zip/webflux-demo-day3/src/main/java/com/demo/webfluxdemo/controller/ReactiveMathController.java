package com.demo.webfluxdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.demo.webfluxdemo.dto.MultiplicationDto;
import com.demo.webfluxdemo.dto.Response;
import com.demo.webfluxdemo.service.ReactiveMathService;

@RestController
@RequestMapping("reactiveMath")
public class ReactiveMathController {
	@Autowired
	private ReactiveMathService reactiveMathService;

	@GetMapping("square/{input}")
	public Mono<Response> findSquare(@PathVariable int input) {
		return this.reactiveMathService.findSquare(input);
	}

	@GetMapping("table/{number}")
	public Flux<Response> multiplicationTable(@PathVariable int number) {
		return this.reactiveMathService.multiplicationTable(number);
	}

	@GetMapping(value = "table/{number}/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Response> multiplicationTableStream(@PathVariable int number) {
		return this.reactiveMathService.multiplicationTable(number);
	}

	@PostMapping("multiply")
	public Mono<Response> multiply(
			@RequestBody Mono<MultiplicationDto> multiplMono) {
		return this.reactiveMathService.multiply(multiplMono);
	}

	
}
