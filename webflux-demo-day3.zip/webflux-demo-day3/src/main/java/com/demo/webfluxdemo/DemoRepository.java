package com.demo.webfluxdemo;

import com.demo.webfluxdemo.dto.BasketEntity;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.relational.core.query.Criteria;
import org.springframework.data.relational.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Repository
public class DemoRepository {

  private static final String EXPORT_STATUS_FIELD = "export_status";

  private final R2dbcEntityTemplate entityTemplate;

  public DemoRepository(R2dbcEntityTemplate entityTemplate) {
    this.entityTemplate = entityTemplate;
  }

  public Mono<BasketEntity> findByBasketId(UUID basketId) {
    return entityTemplate.selectOne(Query.query(Criteria.where("basket_id").is(basketId)),
            BasketEntity.class);
  }

}
