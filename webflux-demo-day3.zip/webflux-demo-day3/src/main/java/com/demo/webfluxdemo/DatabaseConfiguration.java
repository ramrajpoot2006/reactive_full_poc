package com.demo.webfluxdemo;

import io.r2dbc.spi.ConnectionFactory;
import org.springframework.boot.autoconfigure.r2dbc.R2dbcProperties;
import org.springframework.boot.r2dbc.ConnectionFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;

@Configuration
public class DatabaseConfiguration extends AbstractR2dbcConfiguration {

  private final R2dbcProperties r2dbcProperties;

  public DatabaseConfiguration(R2dbcProperties r2dbcProperties) {
    this.r2dbcProperties = r2dbcProperties;
  }

  @Bean
  @Override
  public ConnectionFactory connectionFactory() {
    return ConnectionFactoryBuilder.withUrl(r2dbcProperties.getUrl()).build();
  }

}