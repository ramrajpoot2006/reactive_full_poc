package com.demo.webfluxdemo.dto;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;
import java.util.UUID;

@Table
@Builder(toBuilder = true)
@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class BasketEntity {

  @Id
  private UUID basketId;
  private String orderNo;
  private String eventId;
  private String email;
  private String acid;
  private String exportStatus;
  private  MultiplicationDto dto;
  private LocalDateTime lastModifiedDate;
  private Boolean isLoggedIn;

}
