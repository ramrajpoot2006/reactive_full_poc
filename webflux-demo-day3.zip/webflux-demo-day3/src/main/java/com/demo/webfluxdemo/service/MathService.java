package com.demo.webfluxdemo.service;

import java.util.Arrays;
import java.util.List;

import com.demo.webfluxdemo.DemoRepository;
import com.demo.webfluxdemo.dto.BasketEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.webfluxdemo.dto.Response;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class MathService {

  @Autowired
  private DemoRepository demoRepository;

  public Response findSquare(int input) {

    return new Response(input * input);
  }

  public List<Response> multiplicationTable(int input) {
    return IntStream.range(1, 10).peek(i -> SleepUtil.sleepSeconds(1))
        .peek(i -> System.out.print("Math service processing:" + i))
        .mapToObj(i -> new Response(i * input))
        .collect(Collectors.toList());
  }


  public Mono<BasketEntity> getDetails(String id) {
    return demoRepository.findByBasketId(UUID.fromString(id));
  }

  public Mono<Object> getDetailList(String id) {
    Mono.just("Test");
    Mono.empty();
    getFlux().subscribe(x -> System.out.println("Sum value"+ x));
    return Mono.zip(demoRepository.findByBasketId(UUID.fromString(id))
            ,demoRepository.findByBasketId(UUID.fromString(id)))
        .map(tuple -> tuple.toList());

  }

  //Asynchron
  public Mono<Double> getFlux() {
    List<Double> b = Arrays.asList(1.0,5.0);
    Flux.fromIterable(b).map(val -> Optional.ofNullable(val).orElse(2.9));
    return Flux.fromIterable(b)
        .reduce(0.0, (acc, next) ->  acc + next);

  }

//Synchronous response
  public Double getFlux1() {
    List<Double> b = Arrays.asList(1.0,5.0);
    return b.stream().mapToDouble(Double::doubleValue).sum();
  }
}
